# EduScroll MVP

This is a functional front-end prototype based on the supplied EduScroll plan.

## Run
Open `index.html` in a browser, or serve the folder with any static web server.

## Supabase
The app works in demo/localStorage mode without credentials. For real authentication/database storage:
1. Create a Supabase project.
2. Put the project URL into `localStorage` as `EDUSCROLL_SUPABASE_URL`.
3. Put the anon key into `localStorage` as `EDUSCROLL_SUPABASE_ANON_KEY`.
4. Create the database schema and RLS policies before production use.

The current prototype intentionally does not pretend that client-side `admin=true` is secure. The admin area is UI only until Supabase Auth + RLS policies are configured.

## Included
- Splash -> login
- Sign in / sign up UI
- Google OAuth hook when Supabase is configured
- First-login onboarding
- Language request UI
- Study path, hobbies and sports
- Social-style feed with filters and quiz interaction
- Keyboard feed navigation
- Pomodoro preference
- Groups and create-group UI
- Account/profile/settings
- Digital notebooks with auto-save
- Rich text note tools
- Admin dashboard shell
- Extensible subjects/hobbies/sports folders

## Production integrations still needed
- Full Supabase SQL schema + RLS
- Real posts/comments/likes/saves/shares
- Real-time groups
- Secure admin role claims/policies
- File/image storage
- Push/email notifications
- Actual Pomodoro statistics
- Stylus canvas drawing/eraser/highlighter/shapes/ruler
- Handwriting OCR/recognition provider and calibration workflow
